<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exemplo de Print e Echo com HTML</title>
</head>
<body>
    <?php
    // Definição de uma variável
    $mensagem = "Olá, mundo!";?>
    Usando print para imprimir a mensagem: 
    <?php print $mensagem;?><br>
    Usando echo para imprimir a mesma mensagem:
    <?php echo $mensagem;?>
 </body>
</html>

